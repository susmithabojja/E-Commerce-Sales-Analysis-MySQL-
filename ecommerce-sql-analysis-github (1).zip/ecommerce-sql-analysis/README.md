# E-Commerce Sales Analysis Using MySQL

A relational SQL portfolio project that explores customer activity, product performance, order trends, payment behavior, and business KPIs using a sample e-commerce dataset.

## Project overview

This project demonstrates how SQL can be used to answer practical business questions. The database contains five related tables:

- `customers` — customer profile and signup details
- `products` — product name, category, and unit price
- `orders` — order date, customer, and order status
- `order_items` — products and quantities included in each order
- `payments` — payment method, status, and amount

## Entity relationship diagram

![E-Commerce ER Diagram](images/er_diagram.png)

The model uses primary keys and foreign keys to connect customers to orders, orders to order items and payments, and products to order items.

## Repository structure

```text
ecommerce-sql-analysis/
├── README.md
├── sql/
│   ├── 01_schema.sql
│   ├── 02_sample_data.sql
│   ├── 03_basic_analysis.sql
│   ├── 04_advanced_analysis.sql
│   └── 05_business_kpis.sql
├── images/
│   └── er_diagram.png
└── query-results/
    ├── query_results.md
    ├── kpi_summary.csv
    ├── revenue_by_category.csv
    ├── revenue_by_product.csv
    ├── units_sold_by_product.csv
    ├── monthly_paid_revenue.csv
    ├── customer_paid_spending.csv
    ├── customers_by_city.csv
    └── payment_method_mix.csv
```

## Tools and SQL concepts

**Database:** MySQL 8.0+

**Concepts demonstrated:**
- Database and table creation
- Primary keys, foreign keys, and check constraints
- INSERT, SELECT, WHERE, ORDER BY
- Aggregate functions: `COUNT`, `SUM`, `AVG`
- `GROUP BY` and `HAVING`
- `INNER JOIN` and `LEFT JOIN`
- Subqueries and common table expressions (CTEs)
- Window functions: `RANK`, `DENSE_RANK`, `ROW_NUMBER`, `LAG`
- Conditional aggregation
- Date formatting and monthly analysis
- Business metrics: revenue, average order value, cancellation rate, product mix

## Business questions covered

The SQL scripts answer 25 questions, including:

1. Which customers are from Hyderabad?
2. Which orders are completed?
3. Which products cost more than ₹5,000?
4. How many customers are in each city?
5. How many orders has each customer placed?
6. Which customers have never placed an order?
7. What are the top three products by units sold?
8. Who are the repeat customers?
9. Which customers spend more than the average customer?
10. How do products rank by gross sales?
11. What is paid revenue by month?
12. What is each customer's most recent order?
13. What are total paid revenue, paid order count, and average order value?
14. What is the order cancellation rate?
15. Which product has the second-highest gross sales?
16. Who is the highest-spending customer in each city?
17. What is the running total of monthly paid revenue?
18. Which products have never appeared in an order?
19. What is gross sales by product category?
20. Which payment methods contribute the most collected amount?
21. Which customers have both completed and cancelled orders?
22. What percentage of gross sales does each product contribute?
23. What is month-over-month paid revenue growth?
24. What is the average number of units per completed order?
25. What is the distribution of order statuses?

## How to run the project

Run these files in order using MySQL Workbench or the MySQL command line:

1. `sql/01_schema.sql`
2. `sql/02_sample_data.sql`
3. `sql/03_basic_analysis.sql`
4. `sql/04_advanced_analysis.sql`
5. `sql/05_business_kpis.sql`

Example command-line execution:

```bash
mysql -u your_username -p < sql/01_schema.sql
mysql -u your_username -p < sql/02_sample_data.sql
mysql -u your_username -p < sql/03_basic_analysis.sql
mysql -u your_username -p < sql/04_advanced_analysis.sql
mysql -u your_username -p < sql/05_business_kpis.sql
```

The scripts target MySQL 8.0 or later because they use CTEs and window functions.

## Selected KPI results

The supplied sample data produces the following results:

| KPI | Result |
|---|---:|
| Customers | 8 |
| Orders | 12 |
| Completed orders | 9 |
| Cancelled orders | 1 |
| Pending orders | 2 |
| Paid revenue from completed orders | ₹258,000 |
| Paid completed orders | 9 |
| Average order value | ₹28,666.67 |
| Cancellation rate | 8.33% |

More result tables are in [`query-results/query_results.md`](query-results/query_results.md), with CSV files available for individual outputs.

## Metric definitions and assumptions

- **Paid revenue:** Sum of payment amounts where the payment is `Paid` and the associated order is `Completed`.
- **Gross line-item sales:** Sum of `quantity × product price` for line items belonging to completed orders. This is not necessarily equal to payment revenue.
- **Average order value (AOV):** Paid revenue divided by the number of distinct paid completed orders.
- **Cancellation rate:** Cancelled orders divided by all orders in the sample.
- The sample dataset contains one payment row per order. Real commerce systems may require separate handling for multiple payment attempts, partial payments, refunds, discounts, taxes, and shipping.

## Interview talking points

- Explain why a `LEFT JOIN` is used to retain customers who have no orders.
- Explain the difference between `WHERE` and `HAVING`.
- Explain when to use `RANK`, `DENSE_RANK`, and `ROW_NUMBER`.
- Explain why payment revenue and gross line-item sales are different measures.
- Explain how CTEs make multi-step analytical queries easier to read.

## Future improvements

- Add a returns/refunds table and model partial refunds.
- Add discounts, tax, and shipping fields to calculate net sales.
- Add more rows across multiple months to make trend analysis more meaningful.
- Add an interactive dashboard in Power BI or Tableau.
- Add automated tests for referential integrity and business rules.

---

**Author:** Your Name  
**Project type:** SQL / Data Analytics Portfolio  
**Database:** MySQL 8.0+
